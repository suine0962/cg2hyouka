#加点要素
*textureの実装
